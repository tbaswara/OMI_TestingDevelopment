<?php

class PlnNontaglisMessageHelper extends SyhmponiMessageHelper
{
    public function getFinancialInquiryMessage()
    {
        $jak=new JAK8583();
        $parseDE48=  self::ParseDE48InquiryRequest();
        $inquiry_messageDE48=  self::getNontaglisInquiryMessage($parseDE48);
        $jak->addMTI(self::MTI_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER, "99504");
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER,"258416300");
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION, date("20140806102121"));
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE, "6021");
        $jak->addData(self::DE_BANK_CODE, "4510017");
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,"4510206");
        $jak->addData(self::DE_TERMINAL_ID,"5353");
        $jak->addData(self::DE_ADDITIONAL_DATA,$inquiry_messageDE48);
        
        return $jak->getISO();
        
    }
    
     public function getFinancialPaymentMessage()
    {
         $jak=new JAK8583();
        $parseDE48=  self::ParseDE48PaymentRequest();
        $parseDE62= self::ParseDE62PaymentRequest();
        $inquiry_messageDE48=  self::getNontaglisPaymentMessage($parseDE48);
        $inquiry_messageDE62=  self::getNontaglisPaymentMessageDE62($parseDE62);
        $jak->addMTI(self::MTI_PAYMENT_AND_PURCHASE_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER, "99504");
        $jak->addData(self::DE_TRANSACTION_AMOUNT,"1000000");
        $jak->addData(self::DE_TRANSMISSION_DATE_TIME, date("mdHis"));
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER, date("His"));
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION, date("CYmdhis"));
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE, "6012");
        $jak->addData(self::DE_BANK_CODE, "810");
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,"2221108");
        $jak->addData(self::DE_TERMINAL_ID,"5353129200986789");
        $jak->addData(self::DE_ADDITIONAL_DATA,$parseDE48);
        $jak->addData(self::DE_ADDITIONAL_DATA_2,$parseDE62);
        $jak->addData(self::DE_CURRENCY_CODE_TRANSACTION, "360");
        
        return $jak->getISO();
                
    }
    
     public function getFinancialReversalMessage()
    {
         $jak=new JAK8583();
        $parseDE48=  self::ParseDE48ReversalRequest();
        $parseDE62= self::ParseDE62ReversalRequest();
        $inquiry_messageDE48=  self::getNontaglisReversalMessage($parseDE48);
        $inquiry_messageDE62=  self::getNontaglisReversalMessageDE62($parseDE62);
        $jak->addMTI(self::MTI_REVERSAL_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER, "99504");
        $jak->addData(self::DE_TRANSACTION_AMOUNT,"1000000");
        $jak->addData(self::DE_TRANSMISSION_DATE_TIME, date("mdHis"));
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER, date("His"));
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION, date("CYmdhis"));
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE, "6012");
        $jak->addData(self::DE_BANK_CODE, "810");
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,"2221108");
        $jak->addData(self::DE_TERMINAL_ID,"5353129200986789");
        $jak->addData(self::DE_ADDITIONAL_DATA,$inquiry_messageDE48);
        $jak->addData(self::DE_ADDITIONAL_DATA_2,$inquiry_messageDE62);
        $jak->addData(self::DE_CURRENCY_CODE_TRANSACTION, "360");
        
        return $jak->getISO();
                
    }
    
    public function getNontaglisInquiryMessage($plnnontaglis)
    {
        $inquiry_stringnontaglis=$plnnontaglis->switcher_ID.
                $plnnontaglis->registration_number.
                $plnnontaglis->transaction_code
                ;
        
        return $inquiry_stringnontaglis;
    }

    public function getNontaglisPaymentMessage($plnnontaglis)
    {
        $inquiry_stringnontaglis=$plnnontaglis->switcher_ID.
                $plnnontaglis->registration_number.
                $plnnontaglis->transaction_code.
                $plnnontaglis->transaction_name.
                $plnnontaglis->registration_date.
                $plnnontaglis->expiration_date.
                $plnnontaglis->subscriber_ID.
                $plnnontaglis->subscriber_name.
                $plnnontaglis->pln_reference_number.
                $plnnontaglis->switcher_ReferenceNumber.
                $plnnontaglis->service_unit.
                $plnnontaglis->service_unit_address.
                $plnnontaglis->service_unit_phone.
                $plnnontaglis->total_transaction_amount_minor.
                $plnnontaglis->total_transaction_amount.
                $plnnontaglis->pln_bill_minor_unit.
                $plnnontaglis->pln_bill_value.
                $plnnontaglis->minor_unit_admin_charges.
                $plnnontaglis->admin_charges
                ;
        
        return $inquiry_stringnontaglis;
    }
    
    public function getNontaglisPaymentMessageDE62($plnnontaglis)
    {
        $inquiry_stringnontaglisDE62=$plnnontaglis->bill_component_type.
                $plnnontaglis->bill_component_minor.
                $plnnontaglis->bill_component_value
                ;
        
        return $inquiry_stringnontaglisDE62;
    }
    
    public function getNontaglisReversalMessage($plnnontaglis)
    {
       $inquiry_stringnontaglis=$plnnontaglis->switcher_ID.
                $plnnontaglis->registration_number.
                $plnnontaglis->transaction_code.
                $plnnontaglis->transaction_name.
                $plnnontaglis->registration_date.
                $plnnontaglis->expiration_date.
                $plnnontaglis->subscriber_ID.
                $plnnontaglis->subscriber_name.
                $plnnontaglis->pln_reference_number.
                $plnnontaglis->switcher_ReferenceNumber.
                $plnnontaglis->service_unit.
                $plnnontaglis->service_unit_address.
                $plnnontaglis->service_unit_phone.
                $plnnontaglis->total_transaction_amount_minor.
                $plnnontaglis->total_transaction_amount.
                $plnnontaglis->pln_bill_minor_unit.
                $plnnontaglis->pln_bill_value.
                $plnnontaglis->minor_unit_admin_charges.
                $plnnontaglis->admin_charges
                ;
        
        return $inquiry_stringnontaglis;
    }
    
    public function getNontaglisReversalMessageDE62($plnnontaglis)
    {
        $inquiry_stringnontaglisDE62=$plnnontaglis->bill_component_type.
                $plnnontaglis->bill_component_minor.
                $plnnontaglis->bill_component_value
                ;
        
        return $inquiry_stringnontaglisDE62;

    }

    public function ParseDE48InquiryRequest()
    {
            $plnMessage = new PlnNontaglisMessageHelper();
            $plnMessage->setSwitcherID("0000000");
            $plnMessage->setRegistrationNumber("5123123321589");
            $plnMessage->setTransactionCode("000");
            
            return $plnMessage;
    }
    
     public function  ParseInquiryResponse($iso_response)
    {
          $array_iso=$iso_response;
          $inquiry_response=new stdClass();
          $inquiry_response->mti            =substr($array_iso,0,4);
          $inquiry_response->bitmap         =substr($array_iso,4,16);
          $inquiry_response->length_of_pan  =substr($array_iso,20,2);
          $inquiry_response->pan            =substr($array_iso,22,5);
          $inquiry_response->iso_currency   =substr($array_iso,27,3);
          $inquiry_response->currency_minor =substr($array_iso,30,1);
          $inquiry_response->value_amount   =substr($array_iso,31,12);
          $inquiry_response->stan           =substr($array_iso,43,12);
          $inquiry_response->date_time      =substr($array_iso,55,14);
          $inquiry_response->merchant_code  =substr($array_iso,69,4);
          $inquiry_response->length_bank    =substr($array_iso,73,2);
          $inquiry_response->bank_code      =substr($array_iso,75,7);
          $inquiry_response->length_cid     =substr($array_iso,82,2);
          $inquiry_response->partner_cid    =substr($array_iso,84,7);
          $inquiry_response->response_code  =substr($array_iso,91,4);
          $inquiry_response->terminal_id    =substr($array_iso,95,16);
          $inquiry_response->length_privated=substr($array_iso,111,3);
          $inquiry_response->switcher_id    =substr($array_iso,114,7);
          $inquiry_response->registrationnum=substr($array_iso,121,12);
          $inquiry_response->transactioncode=substr($array_iso,133,3);
          $inquiry_response->transactionname=substr($array_iso,136,25);
          
          if($inquiry_response->response_code=="0000")
          {
              $inquiry_response->registration_date      =substr($array_iso,161,8);
              $inquiry_response->expiration_date        =substr($array_iso,169,8);
              $inquiry_response->subscriber_id          =substr($array_iso,177,12);
              $inquiry_response->subscriber_name        =substr($array_iso,189,25);
              $inquiry_response->pln_refnumber          =substr($array_iso,214,32);
              $inquiry_response->sw_reff                =substr($array_iso,236,32);
              $inquiry_response->service_unit           =substr($array_iso,268,5);
              $inquiry_response->service_unit_address   =substr($array_iso,273,8);
              $inquiry_response->service_unit_phone     =substr($array_iso,281,15);
              $inquiry_response->total_transaction_minor=substr($array_iso,296,1);
              $inquiry_response->total_transactionamount=substr($array_iso,297,17);
              $inquiry_response->pln_bill_minor_unit    =substr($array_iso,314,1);
              $inquiry_response->pln_bill_value         =substr($array_iso,315,10);
              $inquiry_response->admin_charge_minor_unit=substr($array_iso,325,1);
              $inquiry_response->admin_charge           =substr($array_iso,326,10);
              $inquiry_response->length_add_private_data=substr($array_iso,336,3);
              $inquiry_response->bill_component_type    =substr($array_iso,339,2);
              $inquiry_response->bill_component_minor   =substr($array_iso,341,1);
              $inquiry_response->bill_component_value   =substr($array_iso,342,17);
          }
          
          return $inquiry_response;
          
    }    
    
    public function  ParseDE48InquiryResponse()
    {
          $plnMessage = new PlnNontaglisMessageHelper();
          $plnMessage->setSwitcherID();
          $plnMessage->setRegistrationNumber();
          $plnMessage->setTransactionCode();
          $plnMessage->setTransactionName();
          $plnMessage->setRegistrationDate();
          $plnMessage->setExpirationDate();
          $plnMessage->setSubscriberID();
          $plnMessage->setSubscriberName();
          $plnMessage->setPLNReferenceNumber();
          $plnMessage->setSwitcherReferenceNumber();
          $plnMessage->setServiceUnit();
          $plnMessage->setServiceUnitAddress();
          $plnMessage->setServiceUnitPhone();
          $plnMessage->setTotalTransactionAmountMinor();
          $plnMessage->setTotalTransactionAmount();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillValue();
          $plnMessage->setPowerConsumingCategory();
          $plnMessage->setMinorUnitAdminCharger();
          $plnMessage->setAdminCharges();
          
          return $plnMessage;
        
    }
    
    public function ParseDE62InquiryResponse()
    {
        $plnMessage = new PlnNontaglisMessageHelper();
        $plnMessage->setBillComponentType();
        $plnMessage->setBillComponentMinor();
        $plnMessage->setBillComponentValue();
        
        return $plnMessage;
        
    }
    
     public function  ParseDE48PaymentRequest()
    {
          $plnMessage = new PlnNontaglisMessageHelper();
          $plnMessage->setSwitcherID();
          $plnMessage->setRegistrationNumber();
          $plnMessage->setRegistrationDate();
          $plnMessage->setTransactionCode();
          $plnMessage->setTransactionName();
          $plnMessage->setExpirationDate();
          $plnMessage->setSubscriberID();
          $plnMessage->setPLNReferenceNumber();
          $plnMessage->setSwitcherReferenceNumber();
          $plnMessage->setServiceUnit();
          $plnMessage->setServiceUnitAddress();
          $plnMessage->setServiceUnitPhone();
          $plnMessage->setTotalTransactionAmountMinor();
          $plnMessage->setTotalTransaction();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setSubscriberName();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillValue();
          $plnMessage->setMinorUnitAdminCharges();
          $plnMessage->setAdminCharges();
          
          return $plnMessage;
    }
    
    public function  ParseDE62PaymentRequest()
    {
        $plnMessage = new PlnNontaglisMessageHelper();
        $plnMessage->setBillComponentType();
        $plnMessage->setBillComponentMinor();
        $plnMessage->setBillComponentValue();
        
        return $plnMessage;
    }
    
      public function  ParseDE48PaymentResponse()
    {
          $plnMessage = new PlnNontaglisMessageHelper();
          $plnMessage->setLengthPrivateData();
          $plnMessage->setSwitcherID();
          $plnMessage->setRegistrationNumber();
          $plnMessage->setRegistrationDate();
          $plnMessage->setTransactionCode();
          $plnMessage->setTransactionName();
          $plnMessage->setExpirationDate();
          $plnMessage->setSubscriberID();
          $plnMessage->setSubscriberName();
          $plnMessage->setPLNReferenceNumber();
          $plnMessage->setSwitcherReferenceNumber();
          $plnMessage->setServiceUnit();
          $plnMessage->setServiceUnitAddress();
          $plnMessage->setServiceUnitPhone();
          $plnMessage->setTotalTransactionAmountMinor();
          $plnMessage->setTotalTransaction();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillValue();
          $plnMessage->setMinorUnitAdminCharger();
          $plnMessage->setAdminCharges();
          
          return $plnMessage;
                  
    }
    
      public function  ParseDE62PaymentResponse()
    {
        $plnMessage = new PlnNontaglisMessageHelper();
        $plnMessage->setBillComponentType();
        $plnMessage->setBillComponentMinor();
        $plnMessage->setBillComponentValue();
        
        return $plnMessage;
    }
    
      public function  ParseDE48ReversalRequest()
    {
          $plnMessage = new PlnNontaglisMessageHelper();
          $plnMessage->setSwitcherID();
          $plnMessage->setRegistrationNumber();
          $plnMessage->setRegistrationDate();
          $plnMessage->setTransactionCode();
          $plnMessage->setTransactionName();
          $plnMessage->setExpirationDate();
          $plnMessage->setSubscriberID();
          $plnMessage->setSubscriberName();
          $plnMessage->setPLNReferenceNumber();
          $plnMessage->setSwitcherReferenceNumber();
          $plnMessage->setServiceUnit();
          $plnMessage->setServiceUnitAddress();
          $plnMessage->setServiceUnitPhone();
          $plnMessage->setTotalTransactionAmountMinor();
          $plnMessage->setTotalTransactionAmount();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillValue();
          $plnMessage->setMinorUnitAdminCharger();
          $plnMessage->setAdminCharges();
         
          return $plnMessage;
    }
    
      public function  ParseDE62ReversalRequest()
    {
        $plnMessage = new PlnNontaglisMessageHelper();
        $plnMessage->setBillComponentType();
        $plnMessage->setBillComponentMinor();
        $plnMessage->setBillComponentValue();
        
        return $plnMessage;
                  
    }
    
      public function  ParseDE48ReversalResponse()
    {
          $plnMessage = new PlnNontaglisMessageHelper();
          $plnMessage->setLengthPrivateData();
          $plnMessage->setSwitcherID();
          $plnMessage->setRegistrationNumber();
          $plnMessage->setRegistrationDate();
          $plnMessage->setTransactionCode();
          $plnMessage->setTransactionName();
          $plnMessage->setExpirationDate();
          $plnMessage->setSubscriberID();
          $plnMessage->setSubscriberName();
          $plnMessage->setPLNReferenceNumber();
          $plnMessage->setSwitcherReferenceNumber();
          $plnMessage->setServiceUnit();
          $plnMessage->setServiceUnitAddress();
          $plnMessage->setServiceUnitPhone();
          $plnMessage->setTotalTransactionAmountMinor();
          $plnMessage->setTotalTransactionAmount();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillValue();
          $plnMessage->setMinorUnitAdminCharger();
          $plnMessage->setAdminCharges();
          
          return $plnMessage;
    }
    
      public function  ParseDE62ReversalResponse()
    {
        $plnMessage = new PlnNontaglisMessageHelper();
        $plnMessage->setBillComponentType();
        $plnMessage->setBillComponentMinor();
        $plnMessage->setBillComponentValue();
        
        return $plnMessage;
                  
    }
    

}
