<?php

require_once "JAK8583.class.php";
require_once "SyhmponiMessageHelper.php";

class PlnPostPaidMessageHelper extends SyhmponiMessageHelper  {

   
   //Function Convert DE48String
   
   
   public function getInquiryMessage($plnpostpaid)
    {
         
         $inquiryString = $plnpostpaid->switcher_ID.$plnpostpaid->subscriber_ID
                ;
        
        return $inquiryString;
    }
    
    public function getPaymentMessage($plnpostpaid)
    {
        $inquiryString = $plnpostpaid->switcher_ID.
                $plnpostpaid->subscriber_ID.
                $plnpostpaid->bill_status.
                $plnpostpaid->payment_status.
                $plnpostpaid->total_outstandingBill.
                $plnpostpaid->switcher_ID.
                $plnpostpaid->subscriber_name.
                $plnpostpaid->service_unit.
                $plnpostpaid->service_unit_phone.
                $plnpostpaid->subscriber_segmentation.
                $plnpostpaid->power_consuming_category.
                $plnpostpaid->admin_charges.
                $plnpostpaid->bill_period.
                $plnpostpaid->due_date.
                $plnpostpaid->meter_read_date.
                $plnpostpaid->total_electricityBill.
                $plnpostpaid->incenctive.
                $plnpostpaid->value_addedTax.
                $plnpostpaid->penalty_fee.
                $plnpostpaid->previous_meter_reading1.
                $plnpostpaid->current_meter_reading1.
                $plnpostpaid->previous_meter_reading2.
                $plnpostpaid->current_meter_reading2.
                $plnpostpaid->previous_meter_reading3.
                $plnpostpaid->current_meter_reading3;
        
        return $inquiryString;
    }
    
    public function getReversalMessage($plnpostpaid){
        
        $inquiryString = $plnpostpaid->switcher_ID.
                $plnpostpaid->subscriber_ID.
                $plnpostpaid->bill_status.
                $plnpostpaid->payment_status.
                $plnpostpaid->total_outstanding_bill.
                $plnpostpaid->switcher_ID.
                $plnpostpaid->subscriber_name.
                $plnpostpaid->service_unit.
                $plnpostpaid->service_unit_phone.
                $plnpostpaid->subscriber_segmentation.
                $plnpostpaid->power_consuming_category.
                $plnpostpaid->admin_charges.
                $plnpostpaid->bill_period.
                $plnpostpaid->due_date.
                $plnpostpaid->meter_read_date.
                $plnpostpaid->total_electricity_bill.
                $plnpostpaid->incentive.
                $plnpostpaid->value_added_tax.
                $plnpostpaid->penalty_fee.
                $plnpostpaid->previous_meter_reading1.
                $plnpostpaid->current_meter_reading1.
                $plnpostpaid->previous_meter_reading2.
                $plnpostpaid->current_meter_reading2.
                $plnpostpaid->previous_meter_reading3.
                $plnpostpaid->current_meter_reading3;
        
        return $inquiryString;
    }
    


    
    public  function getFinancialInquiryMessage()
    { 
        
        $jak=new JAK8583();
        $parseDE48= self::ParseDE48InquiryRequest();
        $inquiry_message=self::getInquiryMessage($parseDE48);
        $jak->addMTI(self::MTI_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER, "99501");
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER,"258416300");
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION,date("20140806102121"));
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE, "6012");
        $jak->addData(self::DE_BANK_CODE, "4510017");
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,"4510206");
        $jak->addData(self::DE_TERMINAL_ID,"000000000000470");
        $jak->addData(self::DE_ADDITIONAL_DATA,$inquiry_message);
        
        return $jak->getISO();     
                
    }
    
    public function getFinancialPaymentMessage()
    {
        $jak=new JAK8583();
        $parseDE48=  self::ParseDE48PaymentRequest();
        $inquiry_message=  self::getPaymentMessage($parseDE48);
        $jak->addMTI(self::MTI_PAYMENT_AND_PURCHASE_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER, "99501");
        $jak->addData(self::DE_TRANSACTION_AMOUNT,"1000000");
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER, date("His"));
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION, date("CYmdhis"));
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE, "6012");
        $jak->addData(self::DE_BANK_CODE, "4510017");
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,"2221108");
        $jak->addData(self::DE_TERMINAL_ID,"5353129200986789");
        $jak->addData(self::DE_ADDITIONAL_DATA,$inquiry_message);
        $jak->addData(self::DE_CURRENCY_CODE_TRANSACTION, "360");
        
        return $jak->getISO();
                
    }
    
       public function getFinancialReversalMessage()
    {
        $jak=new JAK8583();
        $parseDE48=  self::ParseDE48ReversalRequest();
        $inquiry_message=self::getReversalMessage($parseDE48);
        $jak->addMTI(self::MTI_REVERSAL_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER, "99501");
        $jak->addData(self::DE_TRANSACTION_AMOUNT,"1000000");
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER, date("His"));
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION, date("CYmdhis"));
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE, "6012");
        $jak->addData(self::DE_BANK_CODE, "810");
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,"2221108");
        $jak->addData(self::DE_TERMINAL_ID,"5353129200986789");
        $jak->addData(self::DE_ADDITIONAL_DATA,$inquiry_message);
        $jak->addData(self::DE_CURRENCY_CODE_TRANSACTION, "360");
        
        return $jak->getISO();
                
    }
    
    public function ParseDE48InquiryRequest()
    {
            $plnMessage = new PlnPostPaidMessageHelper();
            
            $plnMessage->setSwitcherID("0000000");
            $plnMessage->setSubscriberID("537612266148"); // ID Pelanggan
            
            return $plnMessage;
    }
    
    public function ParseInquiryRequest()
    {
         $array_iso=$iso_response;
          $inquiry_response=new stdClass();
          $inquiry_response->mti            =substr($array_iso,0,4);
          $inquiry_response->bitmap         =substr($array_iso,4,16);
          $inquiry_response->length_of_pan  =substr($array_iso,20,2);
          $inquiry_response->pan            =substr($array_iso,22,5);
          $inquiry_response->iso_currency   =substr($array_iso,27,3);
          $inquiry_response->currency_minor =substr($array_iso,30,1);
          $inquiry_response->value_amount   =substr($array_iso,31,12);
          $inquiry_response->stan           =substr($array_iso,43,12);
          $inquiry_response->date_time      =substr($array_iso,55,14);
          $inquiry_response->merchant_code  =substr($array_iso,69,4);
          $inquiry_response->length_bank    =substr($array_iso,73,2);
          $inquiry_response->bank_code      =substr($array_iso,75,7);
          $inquiry_response->length_cid     =substr($array_iso,82,2);
          $inquiry_response->partner_cid    =substr($array_iso,84,7);
          $inquiry_response->response_code  =substr($array_iso,91,4);
          $inquiry_response->terminal_id    =substr($array_iso,95,16);
          $inquiry_response->length_privated=substr($array_iso,111,3);
          $inquiry_response->switcher_id    =substr($array_iso,114,7);
          $inquiry_response->subscriber_id  =substr($array_iso,121,12);
        
        
        
    }


    public function  ParseInquiryResponse($iso_response)
    {
          $array_iso=$iso_response;
          $inquiry_response=new stdClass();
          $inquiry_response->mti            =substr($array_iso,0,4);
          $inquiry_response->bitmap         =substr($array_iso,4,16);
          $inquiry_response->length_of_pan  =substr($array_iso,20,2);
          $inquiry_response->pan            =substr($array_iso,22,5);
          $inquiry_response->iso_currency   =substr($array_iso,27,3);
          $inquiry_response->currency_minor =substr($array_iso,30,1);
          $inquiry_response->value_amount   =substr($array_iso,31,12);
          $inquiry_response->stan           =substr($array_iso,43,12);
          $inquiry_response->date_time      =substr($array_iso,55,14);
          $inquiry_response->merchant_code  =substr($array_iso,69,4);
          $inquiry_response->length_bank    =substr($array_iso,73,2);
          $inquiry_response->bank_code      =substr($array_iso,75,7);
          $inquiry_response->length_cid     =substr($array_iso,82,2);
          $inquiry_response->partner_cid    =substr($array_iso,84,7);
          $inquiry_response->response_code  =substr($array_iso,91,4);
          $inquiry_response->terminal_id    =substr($array_iso,95,16);
          $inquiry_response->length_privated=substr($array_iso,111,3);
          $inquiry_response->switcher_id    =substr($array_iso,114,7);
          $inquiry_response->subscriber_id  =substr($array_iso,121,12);
      
          if($inquiry_response->response_code=="0000")
              {
          $inquiry_response->bill_status              =substr($array_iso,133,1);
          $inquiry_response->total_outstanding_bill   =substr($array_iso,134,2);
          $inquiry_response->switcher_reference_number=substr($array_iso,136,32);
          $inquiry_response->subscriber_name          =substr($array_iso,168,25);
          $inquiry_response->service_unit             =substr($array_iso,193,5);
          $inquiry_response->service_unit_phone       =substr($array_iso,198,15);
          $inquiry_response->subscriber_segmentation  =substr($array_iso,213,4);
          $inquiry_response->power_consuming_category =substr($array_iso,217,12);
          $inquiry_response->total_admin_charges      =substr($array_iso,229,9);
          $inquiry_response->bill_period              =substr($array_iso,238,6);
          $inquiry_response->due_date                 =substr($array_iso,244,8);
          $inquiry_response->meter_read_date          =substr($array_iso,252,8);
          $inquiry_response->total_electricity_bill   =substr($array_iso,260,11);
          $inquiry_response->incentive                =substr($array_iso,271,11);
          $inquiry_response->value_added_tax          =substr($array_iso,282,10);
          $inquiry_response->penalty_fee              =substr($array_iso,292,9);
          $inquiry_response->previous_meter_reading1  =substr($array_iso,301,8);
          $inquiry_response->current_meter_reading1   =substr($array_iso,309,8);
          $inquiry_response->previous_meter_reading2  =substr($array_iso,317,8);
          $inquiry_response->current_meter_reading2   =substr($array_iso,325,8);
          $inquiry_response->previous_meter_reading3  =substr($array_iso,333,8);
          $inquiry_response->current_meter_reading3   =substr($array_iso,341,8);
              }
          return $inquiry_response;
    }
        
     public function  ParseDE48PaymentRequest()
    {
          $plnMessage = new PlnPostPaidMessageHelper();
          $plnMessage->setSwitcherID("00000000012");
          $plnMessage->setSubscriberID("00000000000289201");
          $plnMessage->setSubscriberName("John Doe");
          $plnMessage->setSubscriberSegmentation("1234");
          $plnMessage->setBillStatus("1");
          $plnMessage->setBillPeriod("211501");
          $plnMessage->setPaymentStatus("1");
          $plnMessage->setSwitcherReferenceNumber("00000000000012123131223123");
          $plnMessage->setServiceUnit("69697");
          $plnMessage->setServiceUnitPhone("12345567891");
          $plnMessage->setTotalOutstandingBill("10000000");
          $plnMessage->setTotalElectricityBill("2120000");
          $plnMessage->setIncentive("2323122");
          $plnMessage->setPenaltyFee("10000");
          $plnMessage->setPreviousMeterReading1("1003");
          $plnMessage->setCurrentMeterReading1("1299");
          $plnMessage->setPreviousMeterReading2("1699");
          $plnMessage->setCurrentMeterReading2("1800");
          $plnMessage->setPreviousMeterReading3("1000");
          $plnMessage->setCurrentMeterReading3("1234");
          $plnMessage->setPowerConsumingCategory("000000099");
          $plnMessage->setDueDate("22052115");
          $plnMessage->setMeterReadDate("23052115");
          $plnMessage->setAdminCharges("100000");
          
          return $plnMessage;
    }
        
      public function  ParsePaymentResponse()
    {
          $array_iso=$iso_response;
          $inquiry_response=new stdClass();
          $inquiry_response->mti            =substr($array_iso,0,4);
          $inquiry_response->bitmap         =substr($array_iso,4,16);
          $inquiry_response->length_of_pan  =substr($array_iso,20,2);
          $inquiry_response->pan            =substr($array_iso,22,5);
          $inquiry_response->iso_currency   =substr($array_iso,27,3);
          $inquiry_response->currency_minor =substr($array_iso,30,1);
          $inquiry_response->value_amount   =substr($array_iso,31,12);
          $inquiry_response->stan           =substr($array_iso,43,12);
          $inquiry_response->date_time      =substr($array_iso,55,14);
          $inquiry_response->date_settlement=substr($array_iso,69,8);
          $inquiry_response->merchant_code  =substr($array_iso,77,4);
          $inquiry_response->length_bank    =substr($array_iso,81,2);
          $inquiry_response->bank_code      =substr($array_iso,83,7);
          $inquiry_response->length_cid     =substr($array_iso,90,2);
          $inquiry_response->partner_cid    =substr($array_iso,92,7);
          $inquiry_response->response_code  =substr($array_iso,99,4);
          $inquiry_response->terminal_id    =substr($array_iso,103,16);
          $inquiry_response->length_privated=substr($array_iso,119,3);
          $inquiry_response->switcher_id    =substr($array_iso,122,7);
          $inquiry_response->material_number=substr($array_iso,129,11);
          $inquiry_response->subscriber_id  =substr($array_iso,140,12);
          $inquiry_response->flag           =substr($array_iso,152,1);
      
          if($inquiry_response->response_code=="0000")
              {
          $inquiry_response->pln_reference_number     =substr($array_iso,153,1);
          $inquiry_response->switcher_reference_number=substr($array_iso,154,32);
          $inquiry_response->vending_receive_number   =substr($array_iso,186,8);
          $inquiry_response->subscriber_name          =substr($array_iso,168,25);
          $inquiry_response->subscriber_segmentation  =substr($array_iso,193,4);
          $inquiry_response->power_consuming_category =substr($array_iso,197,9);
          $inquiry_response->buying_option            =substr($array_iso,206,1);
          $inquiry_response->minor_admin_charge       =substr($array_iso,207,1);
          $inquiry_response->total_admin_charges      =substr($array_iso,208,10);
          $inquiry_response->minor_stamp_duty         =substr($array_iso,218,1);
          $inquiry_response->stamp_duty               =substr($array_iso,219,10);
          $inquiry_response->minor_unit_add_tax       =substr($array_iso,220,1);
          $inquiry_response->minor_unit_lighting_tax  =substr($array_iso,221,1);
          $inquiry_response->public_lighting_tax      =substr($array_iso,222,10);
          $inquiry_response->minor_unit_installment   =substr($array_iso,232,1);
          $inquiry_response->customer_payable_install =substr($array_iso,233,10);
          $inquiry_response->minor_unit_power_purchase=substr($array_iso,243,1);
          $inquiry_response->power_purchase           =substr($array_iso,244,12);
          $inquiry_response->minor_unit_kwh_purchase  =substr($array_iso,256,1);
          $inquiry_response->purchase_kwh_unit        =substr($array_iso,200,1);
          $inquiry_response->current_meter_reading1   =substr($array_iso,309,8);
          $inquiry_response->previous_meter_reading2  =substr($array_iso,317,8);
          $inquiry_response->current_meter_reading2   =substr($array_iso,325,8);
          $inquiry_response->previous_meter_reading3  =substr($array_iso,333,8);
          $inquiry_response->current_meter_reading3   =substr($array_iso,341,8);
              }
          return $inquiry_response;
                  
    }
    
    
      public function  ParseDE48ReversalRequest()
    {
          $plnMessage = new PlnPostPaidMessageHelper();
          $plnMessage->setSwitcherID("00000000012");
          $plnMessage->setRegistrationNumber();
          $plnMessage->setRegistrationDate();
          $plnMessage->setTransactionCode();
          $plnMessage->setTransactionName();
          $plnMessage->setExpirationDate();
          $plnMessage->setSubscriberID();
          $plnMessage->setSubscriberName();
          $plnMessage->setPLNReferenceNumber();
          $plnMessage->setSwitcherReferenceNumber();
          $plnMessage->setServiceUnit();
          $plnMessage->setServiceUnitAddress();
          $plnMessage->setServiceUnitPhone();
          $plnMessage->setTotalTransactionAmountMinor();
          $plnMessage->setTotalTransactionAmount();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillValue();
          $plnMessage->setMinorUnitAdminCharges();
          $plnMessage->setAdminCharges();
                  
          return $plnMessage;
    }
    
      public function  ParseDE62ReversalRequest()
    {
        $plnMessage = new PlnPostPaidMessageHelper();
        $plnMessage->setBillComponentType();
        $plnMessage->setBillComponentMinor();
        $plnMessage->setBillComponentValue();
        
        return $plnMessage;
                  
    }
    
      public function  ParseDE48ReversalResponse()
    {
          $plnMessage = new PlnPostPaidMessageHelper();
          $plnMessage->setLengthPrivateData();
          $plnMessage->setSwitcherID();
          $plnMessage->setRegistrationNumber();
          $plnMessage->setRegistrationDate();
          $plnMessage->setTransactionCode();
          $plnMessage->setTransactionName();
          $plnMessage->setExpirationDate();
          $plnMessage->setSubscriberID();
          $plnMessage->setSubscriberName();
          $plnMessage->setPLNReferenceNumber();
          $plnMessage->setSwitcherReferenceNumber();
          $plnMessage->setServiceUnit();
          $plnMessage->setServiceUnitAddress();
          $plnMessage->setServiceUnitPhone();
          $plnMessage->setTotalTransactionAmountMinor();
          $plnMessage->setTotalTransactionAmount();
          $plnMessage->setPlnBillMinorUnit();
          $plnMessage->setPlnBillValue();
          $plnMessage->setMinorUnitAdminCharges();
          $plnMessage->setAdminCharges();              
    }
    
      public function  ParseDE62ReversalResponse()
    {
        $plnMessage = new PlnPostPaidMessageHelper();
        $plnMessage->setBillComponentType();
        $plnMessage->setBillComponentMinor();
        $plnMessage->setBillComponentValue();
                  
    }
    

}
