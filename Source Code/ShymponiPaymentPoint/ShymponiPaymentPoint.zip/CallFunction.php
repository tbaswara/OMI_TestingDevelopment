<?php

class CallFunction
{
    
    public function connectprepaid($input_tipe)
    {
        $tipe_transaksi=$input_tipe;
        
        switch($tipe_transaksi)
        {
        
        case "inquiry":
        $contoh="210040300041808100000599501000000867010201503261531056021074510017074567898SIMT2011040412340190000000511020101484";
        $contoh_shymponi="2100403000418081000005995020000000269852015051112173560210745100170745102060000000000000048031JTL53L3142345678910000000000000";
        $contoh_lagiiiii="2100403000418081000005995020000000274532015051811041960210745100170745102060000000000000048031JTL53L3142345678910000000000000";
        $prepaid_inquiry= PlnPrepaidMessageHelper::GetFinancialInquiryMessage();
        var_dump($prepaid_inquiry);
        $connect_prepaid= ISO8583Helpers::getInstance()->sendMessage($contoh_lagiiiii.PHP_EOL);
        if($connect_prepaid['status']==ISO8583Helpers::EVERYTHING_OK)
        {
            $string_response=$connect_prepaid['message'];
            $result=  PlnPrepaidMessageHelper::ParseInquiryResponse($string_response);
            var_dump($string_response);
            var_dump($result);
        }      
        $tam='"';
        $pay="22005030004180810004059950236000000000300000000000274532015051811041960210745100170745102060000000000000048145JTL53L3142345678915511111111110AB2039AA1798F030A9357961FD6C33F1B35CC8BC57483027453989EDB03FCA90BUDIM".$tam."AN/.,ST            R1  9876543212000000000000505151106900            0600020000100000000010000000";
        $prepaid_payment= ISO8583Helpers::getInstance()->sendMessage($pay.PHP_EOL);
        
        if($prepaid_payment['status']==ISO8583Helpers::EVERYTHING_OK)
        {
            $string_response=$prepaid_payment['message'];
            $result=  PlnPrepaidMessageHelper::ParsePaymentResponse($string_response);
            var_dump($string_response);
            var_dump($result);
            
        }
        
        
               
        break;
        
        
        
        case "payment":
         
          $help='"';
         $contoh_transaksi  ="22005030004180810004059950236000000000500000002584163002014080610212160120745100170745102060000000000000000124JTL53L31423456789155111111111100FCFA6CC35719D5F046ED2235457829BAA2D6407B8A2B416300870F9335221D7BUDIMAN/.,STR198765432120000002700050515110690000000060002000000"; 
         $contoh_transaksi_2="220050300041808100040599502360000000005000000025841630020140806102121602107451001707451020600000000000000001240000000142345678910000000000000F61FA5312B8C04AB07F44D765461DC13B1E6BE72578E8416300B05116CD05486BUDIMAN/.,STR198765432120000002700050515110690081313060002000010";
         $contoh_baru_lagipr="2200503000418081000405995023600000000050000000000026985201505111217356012074510017074510206000000000000000012400000001423456789100000000000009EE97AF23A8CA6BA17F974EF6D6DCF2405B2D943E392A0269852EF8FBE895A87BUDIMAN/.,STR1987654321200000000000050515110690000000060002000010";
         $contoh_syhmponi   ="22005030004180810004059950236000000000300000000000274532015051811041960210745100170745102060000000000000048145JTL53L3142345678915511111111110AB2039AA1798F030A9357961FD6C33F1FE8EA9F2D06A902745342084ADECEA68BUDIMAN/.,ST            R1  9876543212000000000000505151106900            0600020000100000000010000000";
        $prepaid_payment= PlnPrepaidMessageHelper::GetFinancialPurchaseMessage();
        $parsing_request=  PlnPrepaidMessageHelper::ParsePaymentRequest($prepaid_payment);
        var_dump($prepaid_payment);
        var_dump($parsing_request);
        $connect_prepaid= ISO8583Helpers::getInstance()->sendMessage($contoh_syhmponi.PHP_EOL);
        
        if($connect_prepaid['status']==ISO8583Helpers::EVERYTHING_OK)
        {
            $string_response=$connect_prepaid['message'];
            $result=  PlnPrepaidMessageHelper::ParsePaymentResponse($string_response);
            var_dump($string_response);
            var_dump($result);
            
        }
        
        
        break;    
        default : echo 'Pesan yang anda masukan salah';
        }
        
    }
    
    public function connectpostpaid()
    {
        $contoh_postpaid="210040300041808100000599501000258416300201408061021216021074510017074510206000000000000000001900000005123123321555\n";
        $inquiry_postpai="210040300041808100000599501000258416300201408061021216021074510017074510206000000000000047701900000000537612266148";
        $contoh_postpaid_payment="22005030004180810000059950136000000001784030000068411662014031913342360210745100170745
102060000000000000477344ST145S3537612266148220245102065376122661489538010000000ASMALI53761123
R1000000900000003200201402200220140000000000000083837D00000000000000000000000006000007
390000075310000000000000000000000000000000000201403200320140000000000000085366D0000000
0000000000000000000000007531000076750000000000000000000000000000000000";
        $postpaid_inquiry=  PlnPostPaidMessageHelper::getFinancialInquiryMessage();
        $connect_postpaid= ISO8583Helpers::getInstance()->sendMessage($postpaid_inquiry.PHP_EOL);
        var_dump($postpaid_inquiry);
        if($connect_postpaid['status']==ISO8583Helpers::EVERYTHING_OK)
        {
            $string_response=$connect_postpaid['message'];
            $result         =  PlnPostPaidMessageHelper::ParseInquiryResponse($string_response);
            var_dump($string_response);
        }

        
    }
    
    public function connectnontaglis()
    {
        $nontaglis_inquiry=  PlnPostPaidMessageHelper::getFinancialInquiryMessage();
        $connect_nontaglis= ISO8583Helpers::getInstance()->sendMessage($nontaglis_inquiry.PHP_EOL);
        
        if($connect_nontaglis['status']==ISO8583Helpers::EVERYTHING_OK)
        {
            $string_response=$connect_nontaglis['message'];
            $result         = PlnNontaglisMessageHelper::ParseInquiryResponse($string_response);
            var_dump($result);
        }
    }
    
    
    
}
