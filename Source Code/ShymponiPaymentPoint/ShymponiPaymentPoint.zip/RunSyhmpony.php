<?php

require_once 'CallFunction.php';
require_once 'PlnPostpaidMessageHelper.php';
require_once 'PlnPrepaidMessageHelper.php';
require_once 'PlnNontaglisMessageHelper.php';
require_once 'JAK8583.class.php';
require_once 'ISO8583Helpers.php';

$input_tipe="inquiry";
CallFunction::connectprepaid($input_tipe);
//CallFunction::connectpostpaid($input_tipe);




