<?php

class PlnPrepaidMessageHelper extends SyhmponiMessageHelper
{
    

    public function getFinancialInquiryMessage()
    {
        $jak=new JAK8583();
        $parseDE48=  self::ParseDE48InquiryRequest();
        $inquiry_stringDE48= self::getPrepaidInquiryMessage($parseDE48);
        $input_stan=258416300;
        $jak->addMTI(self::MTI_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER,99502);
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER,str_pad($input_stan,12,"0",STR_PAD_LEFT));
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION,20140806102121);
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE,6021);
        $jak->addData(self::DE_BANK_CODE, "4510017"); // Bank Code yang digunakan 4510017
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,4510206);
        $jak->addData(self::DE_TERMINAL_ID,"000000000000000");
        $jak->addData(self::DE_ADDITIONAL_DATA,$inquiry_stringDE48);
        
        return $jak->getISO();
        
    }
    
    public function GetFinancialPurchaseMessage()
    {
        $jak=new JAK8583();
        $parseDE48=  self::ParseDE48PurchaseRequest();
        $parseDE62=  self::ParseDE62PurchaseRequest();
        $inquiry_stringDE48=  self::getPrepaidPurchaseMessage($parseDE48);
        $inquiry_stringDE62=  self::getPrepaidPurchaseMessageDE62($parseDE62);
        $input_stan=258416300;
        $currency_code=360;
        $jumlah_uang=50000;
        $total_uang=  str_pad($jumlah_uang,13,"0",STR_PAD_LEFT);
        $jak->addMTI(self::MTI_PAYMENT_AND_PURCHASE_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER,99502);
        $jak->addData(self::DE_TRANSACTION_AMOUNT,($currency_code.$total_uang));
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER,str_pad($input_stan,12,"0",STR_PAD_LEFT));
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION,20150511121735);
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE,6021);
        $jak->addData(self::DE_BANK_CODE, "4510017");
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,4510206);
        $jak->addData(self::DE_TERMINAL_ID,"000000000000000");
        $jak->addData(self::DE_ADDITIONAL_DATA,$inquiry_stringDE48);
        $jak->addData(self::DE_ADDITIONAL_DATA_2,$inquiry_stringDE62);
        
        return $jak->getISO();
    }
    
      public function GetFinancialPurchaseAdviceMessage()
    {
        $jak=new JAK8583();
        $parseDE48=  self::ParseDE48PurchaseAdviceRequest();
        $parseDE62=  self::ParseDE62PurchaseAdviceRequest();
        $inquiry_stringDE48=  self::getPrepaidPurchaseAdviceMessage($parseDE48);
        $inquiry_stringDE62=  self::getPrepaidPurchaseAdviceMessageDE62($parseDE62);
        $jak->addMTI(self::MTI_ADVICE_REQUEST_CODE);
        $jak->addData(self::DE_PRIMARY_ACCOUNT_NUMBER, "99502");
        $jak->addData(self::DE_TRANSACTION_AMOUNT,"100000");
        $jak->addData(self::DE_SYSTEM_TRACE_AUDIT_NUMBER, date("His"));
        $jak->addData(self::DE_DATE_TIME_LOCAL_TRANSACTION, date("CYmdhis"));
        $jak->addData(self::DE_MERCHANT_CATEGORY_CODE, "6021");
        $jak->addData(self::DE_BANK_CODE, "810");
        $jak->addData(self::DE_PARTNER_CENTRAL_ID,"2221108");
        $jak->addData(self::DE_TERMINAL_ID,"5353129200986789");
        $jak->addData(self::DE_ADDITIONAL_DATA,$inquiry_stringDE48);
        $jak->addData(self::DE_ADDITIONAL_DATA_2,$inquiry_stringDE62);
        
        return $jak->getISO();
    }
    
    public function getPrepaidInquiryMessage($plnprepaid)
    {
        $InquiryStringPrepaid=$plnprepaid->switcher_ID.
                $plnprepaid->material_number.
                $plnprepaid->subscriber_ID.
                $plnprepaid->flag
                ;
        
                return $InquiryStringPrepaid;
        
    }
    
    public function getPrepaidPurchaseMessage($plnprepaid)
    {
        $InquiryStringPrepaid=$plnprepaid->switcher_ID.
                $plnprepaid->material_number.
                $plnprepaid->subscriber_ID.
                $plnprepaid->flag.
                $plnprepaid->pln_reference_number.
                $plnprepaid->switcher_ReferenceNumber.
                $plnprepaid->subscriber_name.
                $plnprepaid->subscriber_segmentation.
                $plnprepaid->power_consuming_category.
                $plnprepaid->minor_unit_admin_charges.
                $plnprepaid->admin_charges.
                $plnprepaid->buying_option
                ;
        
                return $InquiryStringPrepaid;
    }
    
    public function getPrepaidPurchaseAdviceMessage($plnprepaid)
    {
        $InquiryStringPrepaid=$plnprepaid->switcher_ID.
                $plnprepaid->material_number.
                $plnprepaid->subscriber_ID.
                $plnprepaid->flag.
                $plnprepaid->pln_reference_number.
                $plnprepaid->switcher_ReferenceNumber.
                $plnprepaid->subscriber_name.
                $plnprepaid->subscriber_segmentation.
                $plnprepaid->power_consuming_category.
                $plnprepaid->minor_unit_admin_charges.
                $plnprepaid->admin_charges.
                $plnprepaid->buying_option
                ;
        
                return $InquiryStringPrepaid;
    }
    
    public function getPrepaidPurchaseMessageDE62($plnprepaid)
    {
            $InquiryStringDE62=$plnprepaid->distribution_code.
                    $plnprepaid->service_unit.
                    $plnprepaid->service_unit_phone.
                    $plnprepaid->max_kwh_unit.
                    $plnprepaid->total_repeat.
                    $plnprepaid->power_purchase
                    ;
            
            return $InquiryStringDE62;
        
    }
    
     public function getPrepaidPurchaseAdviceMessageDE62($plnprepaid)
    {
            $InquiryStringDE62=$plnprepaid->distribution_code.
                    $plnprepaid->service_unit.
                    $plnprepaid->service_unit_phone.
                    $plnprepaid->max_kwh_unit.
                    $plnprepaid->total_repeat.
                    $plnprepaid->pp_repeat
                    ;
        
    }
    
    public function ParseDE48InquiryRequest()
    {
        $plnMessage=new PlnPrepaidMessageHelper();
        $plnMessage->setSwitcherID("0000000");
        $plnMessage->setMaterialNumber(14234567891);
        $plnMessage->setSubscriberID(1428800711); //ID Pelanggan
        $plnMessage->setFlag(0);
        
        return $plnMessage;
        
    }
    

    public function  ParseInquiryResponse($iso_response)
    {
          $array_iso=$iso_response;
          $inquiry_response=new stdClass();
          $inquiry_response->mti            =substr($array_iso,0,4);
          $inquiry_response->bitmap         =substr($array_iso,4,16);
          $inquiry_response->length_of_pan  =substr($array_iso,20,2);
          $inquiry_response->pan            =substr($array_iso,22,5);
          $inquiry_response->stan           =substr($array_iso,27,12);
          $inquiry_response->time           =substr($array_iso,39,14);
          $inquiry_response->merchant       =substr($array_iso,53,4);
          $inquiry_response->lbank          =substr($array_iso,57,2);
          $inquiry_response->bankcode       =substr($array_iso,59,7);
          $inquiry_response->lcid           =substr($array_iso,66,2);
          $inquiry_response->cid            =substr($array_iso,68,7);
          $inquiry_response->rc             =substr($array_iso,75,4);
          $inquiry_response->terminal_id    =substr($array_iso,79,16);
          $inquiry_response->length_privated=substr($array_iso,95,3);
          $inquiry_response->switcher_id    =substr($array_iso,98,7);
          $inquiry_response->material_number=substr($array_iso,105,11);
          $inquiry_response->subscriber_id  =substr($array_iso,116,12);
          $inquiry_response->flag           =substr($array_iso,128,1);
          
          if($inquiry_response->rc=="0000")
          {
              $inquiry_response->pln_reference_num       =substr($array_iso,129,32);
              $inquiry_response->switcher_reference_num  =substr($array_iso,161,32);
              $inquiry_response->subscriber_name         =substr($array_iso,193,25);
              $inquiry_response->subscriber_segmentation =substr($array_iso,218,4);
              $inquiry_response->power_consuming_category=substr($array_iso,222,9);
              $inquiry_response->minor_unit_admin_charges=substr($array_iso,231,1);
              $inquiry_response->admin_charges           =substr($array_iso,232,9);
              $inquiry_response->length_add_private_2    =substr($array_iso,241,3);
              $inquiry_response->distribution_code       =substr($array_iso,244,2);
              $inquiry_response->service_unit            =substr($array_iso,246,5);
              $inquiry_response->service_phone_unit      =substr($array_iso,251,15);
              $inquiry_response->max_kwh_unit            =substr($array_iso,266,5);
              $inquiry_response->total_repeat            =substr($array_iso,271,1);
              $inquiry_response->power_purchase          =substr($array_iso,272,11);
              
          }
          
        
          return $inquiry_response;
    }
    
    public function  ParsePaymentResponse($iso_response)
    {
          $array_iso=$iso_response;
          $inquiry_response=new stdClass();
          $inquiry_response->mti            =substr($array_iso,0,4);
          $inquiry_response->bitmap         =substr($array_iso,4,16);
          $inquiry_response->length_of_pan  =substr($array_iso,20,2);
          $inquiry_response->pan            =substr($array_iso,22,5);
          $inquiry_response->iso_code       =substr($array_iso,27,3);
          $inquiry_response->currency_minor =substr($array_iso,30,1);
          $inquiry_response->value_amount   =substr($array_iso,31,12);
          $inquiry_response->stan           =substr($array_iso,43,12);
          $inquiry_response->time           =substr($array_iso,55,14);
          $inquiry_response->merchant       =substr($array_iso,69,4);
          $inquiry_response->lbank          =substr($array_iso,73,2);
          $inquiry_response->bankcode       =substr($array_iso,75,7);
          $inquiry_response->lcid           =substr($array_iso,82,2);
          $inquiry_response->cid            =substr($array_iso,84,7);
          $inquiry_response->rc             =substr($array_iso,91,4);
          $inquiry_response->terminal_id    =substr($array_iso,95,16);
          $inquiry_response->length_privated=substr($array_iso,111,3);
          $inquiry_response->switcher_id    =substr($array_iso,114,7);
          $inquiry_response->material_number=substr($array_iso,121,11);
          $inquiry_response->subscriber_id  =substr($array_iso,132,12);
          $inquiry_response->flag           =substr($array_iso,144,1);
          
          if($inquiry_response->rc=="0000")
          {
              $inquiry_response->pln_reference_num       =substr($array_iso,145,32);
              $inquiry_response->switcher_reference_num  =substr($array_iso,177,32);
              $inquiry_response->subscriber_name         =substr($array_iso,209,25);
              $inquiry_response->subscriber_segmentation =substr($array_iso,234,4);
              $inquiry_response->power_consuming_category=substr($array_iso,238,9);
              $inquiry_response->minor_unit_admin_charges=substr($array_iso,247,1);
              $inquiry_response->admin_charges           =substr($array_iso,248,9);
              $inquiry_response->length_add_private_2    =substr($array_iso,257,3);
              $inquiry_response->distribution_code       =substr($array_iso,262,2);
              $inquiry_response->service_unit            =substr($array_iso,264,5);
              $inquiry_response->service_phone_unit      =substr($array_iso,269,15);
              $inquiry_response->max_kwh_unit            =substr($array_iso,284,5);
              $inquiry_response->total_repeat            =substr($array_iso,289,1);
              $inquiry_response->power_purchase          =substr($array_iso,290,11);
              
          }
          
        
          return $inquiry_response;
    }
    
    public function  ParsePaymentRequest($iso_response)
    {
          $array_iso=$iso_response;
          $inquiry_response=new stdClass();
          $inquiry_response->mti            =substr($array_iso,0,4);
          $inquiry_response->bitmap         =substr($array_iso,4,16);
          $inquiry_response->length_of_pan  =substr($array_iso,20,2);
          $inquiry_response->pan            =substr($array_iso,22,5);
          $inquiry_response->currency_code  =substr($array_iso,27,3);
          $inquiry_response->minor_unit     =substr($array_iso,30,1);
          $inquiry_response->transacion_jml =substr($array_iso,31,12);
          $inquiry_response->stan           =substr($array_iso,43,12);
          $inquiry_response->time           =substr($array_iso,55,14);
          $inquiry_response->merchant       =substr($array_iso,69,4);
          $inquiry_response->lbank          =substr($array_iso,73,2);
          $inquiry_response->bankcode       =substr($array_iso,75,7);
          $inquiry_response->lcid           =substr($array_iso,82,2);
          $inquiry_response->cid            =substr($array_iso,84,7);
          $inquiry_response->terminal_id    =substr($array_iso,91,16);
          $inquiry_response->length_privated=substr($array_iso,107,3);
          $inquiry_response->switcher_id    =substr($array_iso,110,7);
          $inquiry_response->material_number=substr($array_iso,117,11);
          $inquiry_response->subscriber_id  =substr($array_iso,128,12);
          $inquiry_response->flag           =substr($array_iso,140,1);
          $inquiry_response->pln_rfr_number =substr($array_iso,141,32);
          $inquiry_response->switch_rfr_nmbr=substr($array_iso,173,32);
          $inquiry_response->subscriber_name=substr($array_iso,205,25);
        $inquiry_response->subscriber_segmentation =substr($array_iso,230,4);
              $inquiry_response->power_consuming_category=substr($array_iso,234,9);
              $inquiry_response->minor_unit_admin_charges=substr($array_iso,243,1);
              $inquiry_response->admin_charges           =substr($array_iso,244,10);
              $inquiry_response->buying_option           =substr($array_iso,254,1);
              $inquiry_response->length_add_private_2    =substr($array_iso,255,3);
              $inquiry_response->distribution_code       =substr($array_iso,258,2);
              $inquiry_response->service_unit            =substr($array_iso,260,5);
              $inquiry_response->service_phone_unit      =substr($array_iso,265,15);
              $inquiry_response->max_kwh_unit            =substr($array_iso,280,5);
              $inquiry_response->total_repeat            =substr($array_iso,285,1);
              $inquiry_response->power_purchase          =substr($array_iso,286,11);  
          
          
    
          return $inquiry_response;
    }
    
    public function ParseDE62InquiryResponse()
    {
        $plnMessage = new PlnPrepaidMessageHelper();
        $plnMessage->setDistributionCode();
        $plnMessage->setServiceUnit();
        $plnMessage->setServicePhoneUnit();
        $plnMessage->setMaxKwhUnit();
        $plnMessage->setTotalRepeat();
        $plnMessage->setPowerPurchase();
    
        return $plnMessage;
    }
    
     public function  ParseDE48PurchaseRequest()
    {
          $plnMessage = new PlnPrepaidMessageHelper();
          $plnMessage->setSwitcherID("0000000");
          $plnMessage->setMaterialNumber(14234567891);
          $plnMessage->setSubscriberID("000000000000");
          $plnMessage->setFlag(0);
          $plnMessage->setPLNReferenceNumber("F7A169C266BB39F6871CE6E38AD8C0E0");
          $plnMessage->setSwitcherReferenceNumber("D5D5997AF20EF416300DD99D2264A060");
          $plnMessage->setSubscriberName("BUDIMAN/.,ST");
          $plnMessage->setSubscriberSegmentation("R1");
          $plnMessage->setPowerConsumingCategory(987654321);
          $plnMessage->setMinorUnitAdminCharges(2);
          $plnMessage->setAdminCharges(000000000);
          $plnMessage->setBuyingOption(0);
        
          return $plnMessage;
    }
    
    
    
    public function  ParseDE62PurchaseRequest()
    {
        $plnMessage = new PlnPrepaidMessageHelper();
        $plnMessage->setDistributionCode("05");
        $plnMessage->setServiceUnit("15110");
        $plnMessage->setServicePhoneUnit(6900);
        $plnMessage->setMaxKwhUnit(6000);
        $plnMessage->setTotalRepeat(0);
        $plnMessage->setPowerPurchase(20000100000);
        
        return $plnMessage;
    }
    
      public function  ParseDE48PurchaseResponse()
    {
          $plnMessage = new PLNMessageHelper();
          $plnMessage->setSwitcherID("00000000012");
          $plnMessage->setMaterialNumber("00000000011");
          $plnMessage->setSubscriberID("00000000000289201");
          $plnMessage->setFlag("1");
          $plnMessage->setPLNReferenceNumber("0123456789012345668990");
          $plnMessage->setSwitcherReferenceNumber("00000000000012123131223123");
          $plnMessage->setVendingReceiveNumber("0987592");
          $plnMessage->setSubscriberName("Valentino Rossi");
          $plnMessage->setSubscriberSegmentation("");
          $plnMessage->setPowerConsumingCategory();
          $plnMessage->setMinorUnitAdminCharges();
          $plnMessage->setAdminCharges("100000");
          $plnMessage->setMinorStampDuty("");
          $plnMessage->setStampDuty();
          $plnMessage->setMinorUnitValueAddTax();
          $plnMessage->setValueAddTax();
          $plnMessage->setMinorUnitPublicLightingTax();
          $plnMessage->setPublicLightingTax();
          $plnMessage->setMinorUnitCustomerPayableInstallment();
          $plnMessage->setCustomerPayableInstallment();
          $plnMessage->setMinorUnitPowerPurchase();
          $plnMessage->setPowerPurchase();
          $plnMessage->setPurchaseKwhUnit();
          $plnMessage->setTokenNumber();
                  
          return $plnMessage;
    }
    
      public function  ParseDE62PurchaseResponse()
    {
        $plnMessage = new PLNMessageHelper();
        $plnMessage->setDistributionCode();
        $plnMessage->setServiceUnit();
        $plnMessage->setServicePhoneUnit();
        $plnMessage->setMaxKwhUnit();
        $plnMessage->setTotalRepeat();
        $plnMessage->setPowerPurchase();
                  
        return $plnMessage;
    }
    
      public function  ParseDE48PurchaseAdviceRequest()
    {
          $plnMessage = new PlnPrepaidMessageHelper();
          $plnMessage->setSwitcherID("00000000012");
          $plnMessage->setMaterialNumber("00000000011");
          $plnMessage->setSubscriberID("00000000000289201");
          $plnMessage->setFlag("1");
          $plnMessage->setPLNReferenceNumber("0123456789012345668990");
          $plnMessage->setSwitcherReferenceNumber("00000000000012123131223123");
          $plnMessage->setVendingReceiveNumber("0987592");
          $plnMessage->setSubscriberName("");
          $plnMessage->setSubscriberSegmentation("01233");
          $plnMessage->setPowerConsumingCategory("123456789");
          $plnMessage->setMinorUnitAdminCharges("1");
          $plnMessage->setAdminCharges("10000");
          $plnMessage->setBuyingOption("1");
          
          return $plnMessage;
                  
    }
    
      public function  ParseDE62PurchaseAdviceRequest()
    {
        $plnMessage = new PlnPrepaidMessageHelper();
        $plnMessage->setDistributionCode("01");
        $plnMessage->setServiceUnit("12345");
        $plnMessage->setServicePhoneUnit("0000012356");
        $plnMessage->setMaxKwhUnit("67890");
        $plnMessage->setTotalRepeat("67890");
        $plnMessage->setPowerPurchase("520000");
        
        return $plnMessage;
    }
    
      public function  ParseDE48PurchaseAdviceResponse()
    {
          $plnMessage = new PLNMessageHelper();
          $plnMessage->setLengthPrivateData();
          $plnMessage->setSwitcherID();
          $plnMessage->setMaterialNumber();
          $plnMessage->setSubscriberID();
          $plnMessage->setFlag();
          $plnMessage->setPLNReferenceNumber();
          $plnMessage->setSwitcherReferenceNumber();
          $plnMessage->setSubscriberName();
          $plnMessage->setSubscriberSegmentation();
          $plnMessage->setPowerConsumingCategory();
          $plnMessage->setBuyingOption();
          $plnMessage->setMinorUnitAdminCharges();
          $plnMessage->setAdminCharges();
          $plnMessage->setMinorStampDuty();
          $plnMessage->setStampDuty();
          $plnMessage->setBuyingOption();
          $plnMessage->setMinorUnitValueAddTax();
          $plnMessage->setValueAddTax();
          $plnMessage->setMinorUnitPublicLightingTax();
          $plnMessage->setPublicLightingTax();
          $plnMessage->setMinorUnitCustomerPayableInstallment();
          $plnMessage->setCustomerPayableInstallment();
          $plnMessage->setMinorUnitPowerPurchase();
          $plnMessage->setPowerPurchase();
          $plnMessage->setPurchaseKwhUnit();
          $plnMessage->setTokenNumber();
           
          return $plnMessage;
    }
    
    
    
    
    
    
    
    
    
}
