<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

li {
    display: inline;
}
</style>
</head>
<body>
<ul>
  <li><a href="#home">Prepaid</a></li>
  <li><a href="#news">Postpaid</a></li>
  <li><a href="#contact">Nontaglis</a></li>
</ul>
    
    
    
    <h3>Transaksi Prepaid</h3>
    <h4>Inquiry Result</h4>
    <form action="RunSyhmpony.php">
        Nomor meter   :<p></p><br>
        Nama          :<p></p> <br>
        Tarif/Daya    :<p></p> <br>
        Token Unsold1 :<p></p> <br>
        Token Unsold2 :<p></p> <br>
  
        Nominal Pembelian:<input type="text" name="nometer_idpel" /> <br>
  <input type="submit" value="Inquiry" />
  </form>
</body>
</html>
        
   