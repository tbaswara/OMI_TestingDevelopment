<html>
    <head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

li {
    display: inline;
}
</style>
</head>
<body>
<ul>
    <li><a href="form_input.php">Prepaid</a></li>
    <li><a href="form_input_postpaid.php">Postpaid</a></li>
    <li><a href="form_input_nontaglis.php">Nontaglis</a></li>
</ul>    
    
    <h3>Transaksi Nontaglis</h3>
    <form action="RunSyhmpony.php" name="form_inquiry">
  Nomor Registrasi          : <input type="text" name="subscriber_id" />
  
  <input type="submit" value="Inquiry" />
  </form>
</body>
</html>
        
   